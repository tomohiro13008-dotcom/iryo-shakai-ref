# 医療と社会のレファレンス（個人用）

医療と社会、お金の流れ、自治体行政、医療・介護・福祉の制度、病院とクリニックの経営、2040年の地域医療構想、攻めの予防医療。この7つの棚を一画面で見渡し、会議や交渉の前に引けるようにする個人用のレファレンス。地域医療支援統合アプリの外部レファレンスとして組み込む。

## 引き継ぎ欄

- **現在地**（2026-11-11）：設計と中身（7棚、照合済み）ができた。実装はまだ
- **次の一手**：`START_PROMPT.md` をCodeの新しいセッション（Opus）に貼り、v0の枠を作る

## 置き場所

| パス | 中身 | 正本 |
| --- | --- | --- |
| `docs/design_v0.md` | 設計書（2026-11-11の書き出し） | Claude Docs「医療と社会のレファレンス 設計書 v0（個人用）」 https://claude.ai/artifact/ULuxZk4ovuyuQL3HyLXtn3 |
| `docs/shelves/` | 7棚の中身と使い方・暦（2026-11-11の書き出し） | Claude Docs「医療と社会のレファレンス 中身 v1」 https://claude.ai/artifact/R1Tr4rSb8dhdC2UPVapqtT |
| `source/kyotsu-gakushu-web_v0.html` | 共通学習ツールWeb版（12単元のデータと表示の実装。取り込み元） | https://claude.ai/artifact/NdFbeHqhDDxbqrWejV1X4K |
| `dist/index.html` | レファレンス本体（これから作る。公開するのはこれだけ） | このリポジトリ |

文章の正本はClaude Docs。ここにあるMarkdownは書き出した写しなので、Docsを直したら書き出し直す。

## 関連

- 統合アプリの正本：https://claude.ai/artifact/MYSiYXX18B8yogk8eei1to（v4.0-dev88〜）
- 共通学習ツール 教材v0（12単元の本文）：https://claude.ai/artifact/Lqs5RgQrYWE9dUscQpsozg

## 公開とNetlifyのクレジット

- 作成中はNetlifyにつながない。確認はローカルか、Claudeの公開ページ（Netlifyのクレジットを使わない）
- Netlifyにつなぐときは、本番ブランチを `release` にする。`main` へのpushは本番デプロイにならない
- 念のため `netlify.toml` で、コミットメッセージに `[deploy]` があるときだけビルドする
- Codeからは `.claude/settings.json` でNetlifyのツールとコマンドを禁止してある
- 本番デプロイは1回15クレジット。無料枠は月300（20回分）で、使い切ると全サイトが止まる。ブランチデプロイとデプロイプレビューは0
